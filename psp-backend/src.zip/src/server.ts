import express from "express";
import dotenv from "dotenv";
import { PrismaClient } from "@prisma/client";
import crypto from "crypto";
import { statusRules } from "./core/asserts";
import { sendError } from "./core/httpError";
import { AppError } from "./core/errors";

import { createMerchantRouter } from "./merchant/merchantRoutes";
import { createMerchantRouter as createBankWebhookRouter } from "./upstream/bankWebhooks";

import { PAYMENT_STATUS, PaymentStatus } from "./core/statuses";
import {
  capturePayment,
  refundPayment,
  cancelPayment,
  retryPayment,
} from "./core/transitions";

// import { startProcessing, sendToMockUpsstream } from "./upstream/mockBank";
import { getDefaultProvider, getProviderByCode } from "./providers/registry";
import { maskPanForError, requireFields } from "./core/requestValidation";
import {
  getMerchantOrThrow,
  getPaymentOrThrow,
  getPaymentForMerchantOrThrow,
} from "./core/domain";

import { encryptPan } from "./core/cardCrypto";

dotenv.config();
const cardKeyHex = process.env.CARD_ENC_KEY;

//Режим старта процессинга: auto или manual
const PROCESS_MODE = (process.env.PROCESS_MODE || "auto") as "auto" | "manual";

const MERCH_PAYMENT_TIMEOUT_MS = 60000;
const MERCH_PAYMENT_TIMEOUTCHECKLIST_MS = 30000;

const prisma = new PrismaClient();
const app = express();
const defaultProvider = getDefaultProvider();

const PORT = process.env.PORT || 3000;
app.use(express.json());

//Подключаем мерчантские маршруты
app.use("/merchant", createMerchantRouter(prisma));
app.use("/webhook/upstream", createBankWebhookRouter(prisma));

if (!cardKeyHex) {
  throw new Error("Отсуствует секретный ключ карты");
}
const cardKey = Buffer.from(cardKeyHex, "hex"); //превращаем ключ в байтовый вид

app.get("/payment/status", async (req, res) => {
  try {
    requireFields("query", req.query, ["paymentId"]);

    const rawPaymentId = req.query.paymentId;
    const paymentId =
      typeof rawPaymentId === "string" ? rawPaymentId.trim() : "";

    if (!paymentId) {
      throw AppError.validationInvalidField(
        "query",
        "paymentId",
        "Идентификатор платежа не может быть пустым",
        "EMPTY",
      );
    }

    const payment = await getPaymentOrThrow(prisma, paymentId);

    return res.json({
      id: payment.id,
      status: payment.status,
      amount: payment.amount,
      currency: payment.currency,
      merchantId: payment.merchantId,
      // Через какого провайдера идёт платёж.
      providerCode: payment.providerCode,
      upstreamId: payment.upstreamId,
      upstreamStatus: payment.upstreamStatus, // ⬅️ что сказал банк: authorized / declined / и т.п.
      createdAt: payment.createdAt,
      updatedAt: payment.updatedAt,
    });
  } catch (err) {
    console.error("Ошибка в статуса:", err);
    return sendError(res, err);
  }
});

app.post("/merchant/create", async (req, res) => {
  try {
    requireFields("body", req.body, ["name"]);

    const { name } = req.body;

    const apiKey = "mch_" + crypto.randomBytes(16).toString("hex");

    const merchant = await prisma.merchant.create({
      data: { name, apiKey },
    });
    res.json(merchant);
  } catch (err) {
    console.error("Ошибка создания мерчанта:", err);
    return sendError(res, err);
  }
});

app.post("/payment/init", async (req, res) => {
  try {
    const {
      apiKey,
      amount,
      currency,
      cardNumber,
      expMonth,
      expYear,
      cvv,
      providerCode,
    } = req.body;

    // Если providerCode не передали — используем провайдера по умолчанию.
    const selectedProvider = getProviderByCode(
      providerCode || defaultProvider.code,
    );

    // 1. Проверяем, что обязательные поля вообще переданы
    requireFields("body", req.body, [
      "apiKey",
      "amount",
      "currency",
      "cardNumber",
      "expMonth",
      "expYear",
      "cvv",
    ]);

    //amount > 0, число
    if (typeof amount !== "number" || !Number.isFinite(amount) || amount <= 0) {
      throw AppError.validationInvalidField(
        "body",
        "amount",
        "Сумма должна быть положительным числом",
        amount,
      );
    }

    //Валюта: 3 заглавное
    if (typeof currency !== "string" || !/^[A-Z]{3}$/.test(currency)) {
      throw AppError.validationInvalidField(
        "body",
        "currency",
        "Валюта должна быть строкой из 3 заглавных букв (ISO 4217)",
        currency,
      );
    }

    const panRaw = String(cardNumber ?? "");
    const panClean = panRaw.replace(/\s+/g, "");
    const maskedPan = maskPanForError(panRaw);

    if (!/^\d{12,19}$/.test(panClean)) {
      throw AppError.validationInvalidField(
        "body",
        "cardNumber",
        "Номер карты в неверном формате (только цифры, длина 12–19)",
        maskedPan,
      );
    }

    //подготовка данных карты
    const pan = panClean;
    const bin = pan.slice(0, 6);
    const last4 = pan.slice(-4);

    const expMonthNum = Number(expMonth);
    if (!Number.isInteger(expMonthNum) || expMonthNum < 1 || expMonthNum > 12) {
      throw AppError.validationInvalidField(
        "body",
        "expMonth",
        "Месяц истечения карты должен быть от 1 до 12",
        "XX",
      );
    }

    const expYearNum = Number(expYear);
    const currentYear = new Date().getFullYear();

    if (!Number.isInteger(expYearNum) || expYearNum < currentYear) {
      throw AppError.validationInvalidField(
        "body",
        "expYear",
        "Год истечения карты не может быть в прошлом",
        "XXXX",
      );
    }

    if (expYearNum > currentYear + 20) {
      throw AppError.validationInvalidField(
        "body",
        "expYear",
        "Год истечения карты слишном далекий в будущем",
        "XXXX",
      );
    }

    const cvvStr = String(cvv ?? "");

    if (!/^\d{3,4}$/.test(cvvStr)) {
      throw AppError.validationInvalidField(
        "body",
        "cvv",
        "CVV должен содержать 3-4 цирфы",
        cvvStr.length === 4 ? "XXXX" : "XXX",
      );
    }

    const merchant = await getMerchantOrThrow(prisma, apiKey);

    let brand = "UNKNOWN";
    if (pan.startsWith("4")) brand = "VISA";
    else if (pan[0] === "5") brand = "MASTERCARD";

    const encryptedPan = encryptPan(pan, cardKey); //шифруем PAN

    //Создаем запись карты без cvv
    const card = await prisma.card.create({
      data: {
        merchantId: merchant.id,
        bin,
        last4,
        brand,
        expMonth: expMonthNum,
        expYear: expYearNum,
        encryptedPan,
      },
    });
    // 5. Создаём платёж, привязывая карту
    const payment = await prisma.payment.create({
      data: {
        merchantId: merchant.id,
        amount,
        currency,
        status: PAYMENT_STATUS.CREATED,
        method: "card",
        direction: "in",
        cardId: card.id,
        // Какой провайдер будет обрабатывать этот платёж.
        providerCode: selectedProvider.code,
      },
    });

    await prisma.paymentEvent.create({
      data: {
        paymentId: payment.id,
        type: "created",
        status: PAYMENT_STATUS.CREATED,
        payload: {
          note: "Платеж успешно создан",
          cardLast4: card.last4,
          currency,
          amount,
        },
      },
    });
    // Отдаём платёж
    res.json({
      payment,
      //можно вернуть маскированную карту
      card: {
        brand,
        last4,
        expMonth: expMonthNum,
        expYear: expYearNum,
      },
    });
    //  авто-старт процессинга НА НАШЕЙ СТОРОНЕ - убрать setTImeout потом
    if (PROCESS_MODE === "auto") {
      setTimeout(() => {
        // Запускаем обработку не напрямую через mockBank,
        // а через провайдера.
        defaultProvider.startProcessing(prisma, payment.id).catch((err) => {
          console.error("Ошибка авто-процессинга после инициализации:", err);
        });
      }, 10_000); // 10 секунд до начала PROCESSING
    }
  } catch (err) {
    console.error("Ошибка создания платежа:", err);
    return sendError(res, err);
  }
});

app.listen(PORT, () => {
  console.log(`PSP backend running on port ${PORT}`);
});

setInterval(() => {
  markTimedOutPayments().catch((err) =>
    console.log("Ошибка в периодической проверке таймаутов", err),
  );
}, MERCH_PAYMENT_TIMEOUTCHECKLIST_MS);

app.post("/payment/process", async (req, res) => {
  try {
    requireFields("body", req.body, ["paymentId"]);

    const { paymentId } = req.body;

    // Сначала получаем сам платёж из базы.
    const payment = await getPaymentOrThrow(prisma, paymentId);

    //По коду находим нужный адаптер
    const provider = getProviderByCode(payment.providerCode);

    await provider.startProcessing(prisma, paymentId);

    return res.json({
      ok: true,
      status: "processing",
      providerCode: provider.code,
    });
  } catch (err) {
    console.error("Ошибка процесса платежа:", err);
    return sendError(res, err);
  }
});

// Вызовы от мерчанта

app.post("/payment/capture", async (req, res) => {
  try {
    requireFields("body", req.body, ["apiKey", "paymentId"]);
    const { apiKey, paymentId } = req.body;

    const merchant = await getMerchantOrThrow(prisma, apiKey);

    const payment = await getPaymentForMerchantOrThrow(
      prisma,
      paymentId,
      merchant.id,
    );

    try {
      statusRules.capture.ensure(payment.status as PaymentStatus);
    } catch (e) {
      throw AppError.statusTransitionNotAllowed({
        from: payment.status,
        action: "capture",
        reason: e instanceof Error ? e.message : undefined,
      });
    }

    const updated = await capturePayment(prisma, paymentId);

    return res.json({
      ok: true,
      paymentId: updated.id,
      status: updated.status,
    });
  } catch (err) {
    console.error("Ошибка подтверждения:", err);
    return sendError(res, err);
  }
});

app.post("/payment/refund", async (req, res) => {
  try {
    requireFields("body", req.body, ["apiKey", "paymentId"]);
    const { apiKey, paymentId } = req.body;

    const merchant = await getMerchantOrThrow(prisma, apiKey);
    const payment = await getPaymentForMerchantOrThrow(
      prisma,
      paymentId,
      merchant.id,
    );

    try {
      statusRules.refund.ensure(payment.status as PaymentStatus);
    } catch (e) {
      throw AppError.statusTransitionNotAllowed({
        from: payment.status,
        action: "refund",
        reason: e instanceof Error ? e.message : String(e),
      });
    }
    const updated = await refundPayment(prisma, paymentId);

    return res.json({
      ok: true,
      paymentId: updated.id,
      status: updated.status,
    });
  } catch (err) {
    console.error("Ошибка возврата", err);
    return sendError(res, err);
  }
});

app.post("/payment/cancel", async (req, res) => {
  try {
    requireFields("body", req.body, ["apiKey", "paymentId"]);
    const { apiKey, paymentId } = req.body;
    const merchant = await getMerchantOrThrow(prisma, apiKey);
    const payment = await getPaymentForMerchantOrThrow(
      prisma,
      paymentId,
      merchant.id,
    );
    try {
      statusRules.cancel.ensure(payment.status as PaymentStatus);
    } catch (e) {
      throw AppError.statusTransitionNotAllowed({
        from: payment.status,
        action: "cancel",
        reason: e instanceof Error ? e.message : String(e),
      });
    }

    const updated = await cancelPayment(prisma, paymentId);
    return res.json({
      ok: true,
      paymentId: updated.id,
      status: updated.status,
    });
  } catch (err) {
    console.error("Ошибка отмены:", err);
    return sendError(res, err);
  }
});

app.post("/payment/retry", async (req, res) => {
  try {
    requireFields("body", req.body, ["apiKey", "paymentId"]);
    const { apiKey, paymentId } = req.body;

    const merchant = await getMerchantOrThrow(prisma, apiKey);
    const payment = await getPaymentForMerchantOrThrow(
      prisma,
      paymentId,
      merchant.id,
    );

    try {
      statusRules.retry.ensure(payment.status as PaymentStatus);
    } catch (e) {
      throw AppError.statusTransitionNotAllowed({
        from: payment.status,
        action: "retry",
        reason: e instanceof Error ? e.message : undefined,
      });
    }
    const updated = await retryPayment(prisma, paymentId);

    const provider = getProviderByCode(updated.providerCode);

    provider
      .retryProcessing(prisma, paymentId)
      .catch((err) =>
        console.error("Ошибка Банк-эквайера при повторной оплате", err),
      );
    return res.json({
      ok: true,
      paymentId: updated.id,
      status: updated.status,
      providerCode: provider.code,
    });
  } catch (err) {
    console.error("Ошибка при повторной оплате:", err);
    return sendError(res, err);
  }
});

async function markTimedOutPayments() {
  try {
    const deadline = new Date(Date.now() - MERCH_PAYMENT_TIMEOUT_MS);

    // Ищем платежи, которые в статусе PROCESSING, их updatedAt старше чем deadline
    // т.е. висим дольше таймаута
    const pending = await prisma.payment.findMany({
      where: {
        status: PAYMENT_STATUS.PROCESSING,
        updatedAt: {
          lt: deadline,
        },
      },
    });

    if (!pending.length) {
      return;
    }

    console.log(
      `Таймаут: найдено платежей в PROCESSING дольше лимита: ${pending.length}`,
    );

    //Проходимся по массиву и ставим статус TIMEOUT
    for (const p of pending) {
      await prisma.payment.update({
        where: { id: p.id },
        data: {
          status: PAYMENT_STATUS.TIMEOUT,
        },
      });

      //Пишем событие "timeout" в историю
      await prisma.paymentEvent.create({
        data: {
          paymentId: p.id,
          type: "timeout",
          status: PAYMENT_STATUS.TIMEOUT,
          payload: {
            note: "Истекло время ожидания ответа банка",
            timeoutMs: MERCH_PAYMENT_TIMEOUT_MS,
          },
        },
      });
      console.log(`Таймаут: платёж ${p.id} помечен как TIMEOUT`);
    }
  } catch (err) {
    console.error("Ошибка при обработке таймаутов платежей:", err);
  }
}

//Создание мерчанта

// curl -X POST "http://localhost:3000/merchant/create" \
//   -H "Content-Type: application/json" \
//   -d "{\"name\": \"TestMerchant\"}"

//Создание платежа

// curl -X POST "http://localhost:3000/payment/init"   -H "Content-Type: application/json"   -d "{
//     \"apiKey\": \"mch_3fbc81d66f4d6efa6ab9a9f802745d9a\",
//     \"amount\": 100.50,
//     \"currency\": \"EUR\",
//     \"cardNumber\": \"4111 1111 1111 1111\",
//     \"expMonth\": 12,
//     \"expYear\": 2030,
//     \"cvv\": \"123\"
//   }"

// curl -X POST http://localhost:3000/webhook/upstream/payment-result \
//     -H "Content-Type: application/json"
//     -H "x-webhook-sign: 094be207fa8af92f9869ece7e16deb7cd296db9c46b7febfba9f51bc6a39a215" \
//     -d "{
//     \"paymentId\": \"cmio0ioky0002tur2995t8aev\",
//     \"status\": \"approved\",
//     \"bankTransactionId\": \"BNK123456\",
//     \"raw\": {\"example\": true}
//   }"

// Подтверждение authorized
// curl -X POST http://localhost:3000/payment/process   -H "Content-Type: application/json"   -d "{
//     \"paymentId\": \"cmio3ew84000fclb3rm5x8sh2\"
//   }"

// Подтверждение списания

//Узнать статус одного платежа
// curl "http://localhost:3000/payment/status?paymentId=ТВОЙ_ID"

//node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
//генерация
