import { Router } from "express";
import { PrismaClient } from "@prisma/client";
import { sendError } from "../core/httpError";
import { AppError } from "../core/errors";
import { getMerchantOrThrow } from "../core/domain";

export function createMerchantRouter(prisma: PrismaClient) {
  const router = Router();

  //health-check
  router.get("/health", (_req, res) => {
    res.json({ status: "ok" });
  });

  //список мерчантов
  router.get("/merchants", async (_req, res) => {
    try {
      // 1) Берём apiKey из заголовков
      const apiKey = _req.header("x-api-key");

      // 2) Проверяем, что apiKey вообще передан
      if (!apiKey) {
        throw AppError.validationMissingFields("headers", ["apiKey"]);
      }

      // 3) Проверяем, что такой мерчант существует
      await getMerchantOrThrow(prisma, apiKey);

      const merchants = await prisma.merchant.findMany();
      res.json(merchants);
    } catch (err) {
      console.error("Ошибка загрузки мерчантов: ", err);
      return sendError(res, err);
    }
  });
  return router;
}
